---
title: test
date: 2021-07-06 20:57:44
tags:
---
 
![这是代替图片的文字，随便写](images/1.jpeg)

![这是代替图片的文字，随便写](./1.jpeg)

![这是代替图片的文字，随便写](test/1.jpeg)

{% asset_img 1.jpeg This is an example image %}